# Harbor runtime, effect and artifact commit contracts

## Durable run state
States: `CREATED → PLANNING → RUNNING`; RUNNING may enter `WAITING_APPROVAL`, `PAUSED`, `CANCELLING`, `COMPLETED`, or `FAILED`. WAITING_APPROVAL may return to RUNNING or end in PAUSED/CANCELLING/FAILED. PAUSED may resume to RUNNING or cancel. CANCELLING ends only as CANCELLED after executor/tool cancellation acknowledgement. Terminal states are COMPLETED, FAILED and CANCELLED.

Pause reasons are persisted: `user`, `background`, `thermal`, `resource_pressure`, `source_unavailable`, `network_policy`, `effect_outcome_unknown`. Active-runtime budgets count executor-active time; wall time is recorded separately. Step/tool/context counters are monotonic durable totals.

Exactly one executor may own a run. Ownership is a generation-fenced lease stored transactionally with run state. A stale process cannot append authoritative events or effects after losing its generation.

Unknown events are safe only when the generic envelope says `replay_semantics=ignorable_display`. Unknown state- or authority-affecting events halt replay and require a compatible runtime.

## External effects
Before dispatch Harbor persists an immutable effect intent containing canonical arguments, target identity, policy version, effect ID, approval binding and idempotency strategy. Effect state is `prepared`, `dispatched`, `committed`, `outcome_unknown` or `aborted`.

After `dispatched` but before local `committed`, restart performs provider reconciliation. If the provider supports an idempotency key, Harbor reuses the same key. If a reliable read-after-write reconciliation path exists, Harbor uses it. If neither exists, Harbor must not retry automatically and surfaces `outcome_unknown`.

Allow-once approval expires after 15 minutes or run termination, whichever is earlier. Persistent permissions are policy records, not reusable effect receipts. Approval is bound to canonical arguments, target, effect class and policy version. Artifact approvals additionally bind base content hash and proposed output hash.

## Artifact operation batch
Every mutation uses `harbor.artifact_batch/v2`: artifact ID, base version ID, base content hash, unique batch ID, unique operation IDs, per-operation preconditions and proposed output hash. Cell writes are not exempt.

Immediately before commit Harbor reacquires the file capability and verifies the current target matches the approved base. All operations are applied to a staged output. The staged result is validated and hashed. Where the platform offers atomic same-filesystem replacement Harbor uses it; otherwise Harbor writes a new version/copy and never destroys the old file until the platform-specific safe-replace contract succeeds.

A batch is all-or-nothing. Partial acceptance creates new dependency-safe sub-batches and requires new hashes/approval. Replaying a committed batch ID is a no-op that returns the committed version.
