# Harbor review reconciliation matrix

Reviewed findings have been converted into normative contracts and executable release evidence requirements. `Resolved` means the specification gap is closed; it does **not** mean the running product has passed the required evidence.

| # | Finding | Spec status | Authority files | Implementation task(s) | Gate(s) | Resolution |
|---:|---|---|---|---|---|---|
| 1 | Release scope/dependencies executable | Resolved | 01,04,05,18,19,20 | HBR-147 | ACC-041 | Milestone/priority separated; feature/platform applicability, blocking, owner, task/evidence mappings; N/A_DISABLED semantics. |
| 2 | Durable run state model | Resolved | 02,03,schemas/run_event.schema.json | HBR-148 | ACC-042; ACC-043 | PAUSED/CANCELLING states, persisted reasons, active-time budget, generation-fenced single executor, unknown authority event fail-closed. |
| 3 | Uncertain external effects | Resolved | 02,03,schemas/effect_intent.schema.json | HBR-149 | ACC-044; ACC-045 | prepared/dispatched/committed/outcome_unknown, provider idempotency/reconciliation, no unsafe automatic retry. |
| 4 | Stale-write protection | Resolved | 02,03,schemas/artifact_batch.schema.json | HBR-151 | ACC-046; ACC-047 | base version/hash, op preconditions, proposal hash, approval binding, immediate precommit revalidation, atomic/versioned fallback. |
| 5 | Network exceptions/enforcement | Resolved | 13 | HBR-150 | ACC-038; ACC-048 | Explicit egress policy classes; broker across app-controlled transports; redirect reauthorization; blocked/dispatched/completed attribution; OS-owned traffic separated. |
| 6 | Protection outside SQLite | Resolved | 13 | HBR-152 | ACC-049; ACC-050 | Per-workspace encrypted private blob store, key hierarchy/rotation, temp/cache/backup policy, crypto-erasure and reference-count cleanup. |
| 7 | Office calculation/rendering | Resolved contract; evidence still required | 12,21,22 | HBR-153; HBR-161 | ACC-051; ACC-052; ACC-063 | Selected formula/renderer strategy; executable support matrix and formula qualification manifest; unsupported/stale dependencies cannot be verified. |
| 8 | Device/performance promises measurable | Resolved contract; thresholds await measurements | 12,15 | HBR-154 | ACC-053; ACC-054 | Support floors, workload definitions, memory envelope, lowest-device measurement; remaining TBD performance thresholds block GA. |
| 9 | Answer quality/index compatibility | Resolved | 16 | HBR-155 | ACC-055; ACC-056 | Full index identity/versioning; rebuild/isolate incompatible index; EN/AR groundedness, abstention, citation correctness and source-removal behavior. |
| 10 | Sync conflict/device/key semantics | Resolved; sync remains disabled until qualified | 11 | HBR-156 | ACC-057 | Device identity, key epochs, tombstones, conflict rules, no approval/capability transfer, single run authority semantics. |
| 11 | Provider/model package contracts | Resolved | 17,schemas/model_package.schema.json | HBR-157 | ACC-058 | ModelRef variants, capabilities, cancellation/cleanup, atomic multi-file packages, no arbitrary remote code, catalog key epoch/rollback rules. |
| 12 | Accessible token pairs | Resolved at token-contract level | 06,07 | HBR-158 | ACC-059 | Semantic text/fill/border/on-fill roles; current normal-text pairs pass >4.5 unrounded; EN/AR/state-level component audit remains release evidence. |
| 13 | Arabic content vs UI support | Resolved | 14 | HBR-159 | ACC-060 | Feature-by-language matrix; offline Arabic OCR fallback selected; speech feature-gated; generated artifact/RTL support separately qualified. |
| A | Screen ownership / states | Resolved | 07 | HBR-160 | ACC-061; ACC-062 | Every route is mapped to owner/milestone/tasks/evidence; exceptional states are first-class screens. |

## Interpretation

- A contract marked resolved can still have a release gate in `BLOCKED` state until implementation evidence exists.
- Optional features are not counted as passed when disabled; they resolve to `N/A_DISABLED`.
- A release cannot be sealed if any selected blocking gate lacks evidence or is `TBD`, `BLOCKED`, or `FAIL`.