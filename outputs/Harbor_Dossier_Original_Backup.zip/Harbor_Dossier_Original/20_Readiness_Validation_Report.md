# Harbor reconciled structural validation

- Tasks: 114 (91 P0, 21 P1, 2 P2)
- Acceptance gates: 63
- Screens/routes: 47
- Security scenarios: 47
- Office feature contract rows: 23
- Formula target entries: 71 (PASS now: 0; qualification is intentionally evidence-blocked)
- Core GA required blocking gates under selected core/public-HF/RAG/Arabic-OCR feature set: 60
- Dependency graph acyclic: True

## Semantic contrast checks
- light / statusLocal: 5.459:1 — PASS
- light / statusHybrid: 5.818:1 — PASS
- light / statusRemote: 6.018:1 — PASS
- light / statusDanger: 6.055:1 — PASS
- light / primaryAction: 5.887:1 — PASS
- dark / statusLocal: 8.583:1 — PASS
- dark / statusHybrid: 8.512:1 — PASS
- dark / statusRemote: 8.256:1 — PASS
- dark / statusDanger: 7.54:1 — PASS
- dark / primaryAction: 8.136:1 — PASS

## Validation issues
None.

## Important interpretation
- Structural PASS means the specification ledgers are internally consistent. It does not substitute for implementation evidence.
- Formula entries remain unqualified until HBR-153 records the exact vendored engine source revision/hash and the fixture suite passes. Performance thresholds marked TBD/BLOCKED remain release blockers until measured.