# Harbor optional sync protocol authority

Sync is disabled by default and may be enabled only after ACC-057 passes.

## Authority separation
Sync replicates content/history, not OS file handles, local capability receipts, local executor leases, or allow-once approval receipts. A synchronized run is history unless it is explicitly transferred. Cross-device transfer creates a new execution authority context and invalidates old one-time approvals.

## Cryptography and devices
Each device has an identity signing key and encryption key in the OS secure store. A sync group has an epoch key. New-device enrollment requires authenticated approval from an existing device or a recovery secret. Revocation advances the epoch for future records. Revocation cannot erase plaintext already obtained by the revoked device.

## Record envelope
Every encrypted record carries group ID, device ID, device sequence, key epoch, record type, object ID, hybrid logical clock, previous-device-record hash, tombstone flag and authenticated ciphertext. Duplicate sequence/record IDs and invalid epochs are rejected.

## Conflict rules
Chats and run-history events are append-only. Settings use field-level last-writer-wins only for explicitly safe settings. Artifact edits fork versions on concurrency; no binary last-writer overwrite. Delete-vs-edit produces a visible conflict/tombstone state. Skill edits fork if both changed. Model weights are not synchronized.

## Offline and restore
Restored old backups cannot roll the group epoch backward. Tombstones have a retention horizon long enough to reach known devices. Server data is ciphertext plus routing metadata only.
