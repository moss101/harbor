# Harbor release and scope authority

## Terminology
Delivery **milestone** and engineering **priority** are separate. Milestones are `M0_CONTRACT`, `M1_LOCAL_REFERENCE`, `M2_PLATFORM_BETA`, `M3_GA_CORE`, and `M4_OPTIONAL_SERVICES`. Priorities are P0/P1/P2 and never imply release applicability by themselves.

## Gate-selection algorithm
For a proposed build, declare `platform`, `milestone`, and enabled feature flags. A gate is required when: (1) its Blocking field is Yes; (2) its milestone is at or before the target milestone; (3) its platform applies; and (4) its feature applicability expression is enabled. Disabled optional capability gates are `N/A_DISABLED`, never PASS. Platform-inapplicable gates are `N/A_PLATFORM`. Every PASS must name evidence and the exact commit/build identity.

## Core GA feature set
Core GA includes the adaptive shell, GGUF local inference, device-aware model library, direct public Hugging Face model acquisition, agent runtime, protected effects, local files/PDF, Office artifact work, local RAG/Knowledge, EN/AR UI, accessibility, privacy/network observability, crash recovery and four-platform packaging.

## Optional services
Authenticated/gated Hub access, remote inference/endpoints, third-party connectors, diagnostics upload and E2EE sync remain disabled unless their own M4 gates pass. Their absence cannot be represented as a passed gate.

## Evidence rule
Task completion is not evidence. Release evidence must be reproducible output: test report, trace, artifact hashes, packet capture comparison, device benchmark result, accessibility report, store validation output, or equivalent. `05_Acceptance_Matrix.csv` is the executable gate catalog.
