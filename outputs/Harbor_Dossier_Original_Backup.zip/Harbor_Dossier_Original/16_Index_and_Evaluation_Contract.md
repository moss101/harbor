# Harbor index and evaluation contract

`IndexIdentity` includes embedding provider/model content hash, vector dimension, chunker ID/version/config, tokenizer ID/version, normalization policy, language policy and encryption scope. A changed identity never reuses an old vector namespace. Harbor builds a new index, atomically switches after validation, then retires the old one.

Removing/revoking a source immediately excludes it from future retrieval and schedules chunk/cache deletion. Existing chat text remains historical unless the user selects purge-derived-content; its citation resolves as `source_removed` and is not treated as current evidence.

The pinned evaluation suite contains English, Arabic and mixed-language cases for retrieval recall, citation support, contradictory sources, insufficient-evidence abstention, prompt injection, tool selection, numerical calculation and protected-effect avoidance. Passing requires zero unauthorized effects. Numerical and citation gates use exact expected fixtures where available rather than subjective grading. Dataset version, evaluator version, model/runtime identity and thresholds are stored with results.
